import { FormEvent, useEffect, useRef, useState } from 'react';

type Screen =
  | 'home'
  | 'conversation'
  | 'search'
  | 'profile'
  | 'settings'
  | 'credits'
  | 'voice'
  | 'missions'
  | 'notifications'
  | 'auth';

type IconName =
  | 'menu'
  | 'edit'
  | 'more'
  | 'plus'
  | 'mic'
  | 'arrow'
  | 'search'
  | 'archive'
  | 'trash'
  | 'close'
  | 'chevron'
  | 'user'
  | 'settings'
  | 'credit'
  | 'logout'
  | 'file'
  | 'image'
  | 'camera'
  | 'check'
  | 'bell'
  | 'briefcase'
  | 'shield'
  | 'globe'
  | 'help'
  | 'phone'
  | 'stop'
  | 'wifi'
  | 'back'
  | 'package';

const paths: Record<IconName, React.ReactNode> = {
  menu: <><path d="M4 7h16M4 12h16M4 17h16" /></>,
  edit: <><path d="M12 20h9" /><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z" /></>,
  more: <><circle cx="5" cy="12" r="1" /><circle cx="12" cy="12" r="1" /><circle cx="19" cy="12" r="1" /></>,
  plus: <><path d="M12 5v14M5 12h14" /></>,
  mic: <><rect x="9" y="3" width="6" height="12" rx="3" /><path d="M5 11a7 7 0 0 0 14 0M12 18v3" /></>,
  arrow: <><path d="m6 12 6-6 6 6M12 6v12" /></>,
  search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
  archive: <><path d="M4 7h16v13H4zM3 4h18v3H3zM9 11h6" /></>,
  trash: <><path d="M4 7h16M9 7V4h6v3M7 7l1 14h8l1-14M10 11v6M14 11v6" /></>,
  close: <><path d="m6 6 12 12M18 6 6 18" /></>,
  chevron: <><path d="m9 18 6-6-6-6" /></>,
  user: <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>,
  settings: <><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3A1.7 1.7 0 0 0 10 3V2.8h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z" /></>,
  credit: <><rect x="3" y="5" width="18" height="14" rx="3" /><path d="M3 10h18M7 15h3" /></>,
  logout: <><path d="M10 17l5-5-5-5M15 12H3M15 4h5v16h-5" /></>,
  file: <><path d="M6 2h8l4 4v16H6zM14 2v5h5" /></>,
  image: <><rect x="3" y="4" width="18" height="16" rx="2" /><circle cx="9" cy="10" r="2" /><path d="m3 17 5-5 4 4 3-3 6 6" /></>,
  camera: <><path d="M4 7h4l2-3h4l2 3h4v13H4z" /><circle cx="12" cy="13" r="4" /></>,
  check: <><path d="m5 12 4 4L19 6" /></>,
  bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4" /></>,
  briefcase: <><rect x="3" y="7" width="18" height="13" rx="2" /><path d="M9 7V4h6v3M3 12h18M10 12v2h4v-2" /></>,
  shield: <><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z" /><path d="m9 12 2 2 4-5" /></>,
  globe: <><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18" /></>,
  help: <><circle cx="12" cy="12" r="9" /><path d="M9.5 9a2.6 2.6 0 1 1 4.2 2c-1 .7-1.7 1.1-1.7 2.5M12 17h.01" /></>,
  phone: <><path d="M8 3H5a2 2 0 0 0-2 2c0 8.8 7.2 16 16 16a2 2 0 0 0 2-2v-3l-4-1-2 2c-3.7-1.6-6.4-4.3-8-8l2-2Z" /></>,
  stop: <><rect x="7" y="7" width="10" height="10" rx="2" /></>,
  wifi: <><path d="M2 8a15 15 0 0 1 20 0M5 12a10 10 0 0 1 14 0M8.5 16a5 5 0 0 1 7 0M12 20h.01" /></>,
  back: <><path d="m15 18-6-6 6-6" /></>,
  package: <><path d="m12 3 9 5-9 5-9-5 9-5ZM3 8v9l9 5 9-5V8M12 13v9" /></>,
};

function Icon({ name, size = 22 }: { name: IconName; size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden>{paths[name]}</svg>;
}

function Logo({ small = false }: { small?: boolean }) {
  return <div className={small ? 'logo small' : 'logo'}><span>t</span></div>;
}

const conversations = [
  ['Fournisseur de café pour bureau', 'Aujourd’hui'],
  ['Comparer trois devis imprimeur', 'Aujourd’hui'],
  ['Réserver une salle à Dakar', 'Hier'],
  ['Mission photographe produit', '7 derniers jours'],
  ['Commande de mobilier', '7 derniers jours'],
];

function AppHeader({ title = 'Trezutil', onMenu, onNew, back }: { title?: string; onMenu?: () => void; onNew?: () => void; back?: () => void }) {
  return <header className="app-header">
    <button className="icon-btn" onClick={back || onMenu} aria-label={back ? 'Retour' : 'Ouvrir le menu'}><Icon name={back ? 'back' : 'menu'} /></button>
    <button className="title-button"><span>{title}</span>{!back && <span className="model-pill">Commerce OS</span>}</button>
    {onNew ? <button className="icon-btn" onClick={onNew} aria-label="Nouvelle conversation"><Icon name="edit" /></button> : <span className="icon-space" />}
  </header>;
}

function Composer({ onSend, onAttach, onVoice, generating, stop }: { onSend: (text: string) => void; onAttach: () => void; onVoice: () => void; generating: boolean; stop: () => void }) {
  const [text, setText] = useState('');
  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    onSend(text.trim());
    setText('');
  };
  return <div className="composer-wrap">
    <form className="composer" onSubmit={submit}>
      <button type="button" className="composer-btn add" onClick={onAttach} aria-label="Ajouter"><Icon name="plus" size={21} /></button>
      <textarea value={text} onChange={e => setText(e.target.value)} placeholder="Écrire à Trezutil" rows={1} />
      {!text && !generating && <button type="button" className="composer-btn" onClick={onVoice} aria-label="Dicter"><Icon name="mic" size={21} /></button>}
      <button type={generating ? 'button' : 'submit'} onClick={generating ? stop : undefined} className={`send-btn ${text || generating ? 'active' : ''}`} aria-label={generating ? 'Arrêter' : 'Envoyer'}>
        <Icon name={generating ? 'stop' : 'arrow'} size={18} />
      </button>
    </form>
    <p className="composer-note">Trezutil peut faire des erreurs. Vérifiez les informations importantes.</p>
  </div>;
}

function Home({ start, openDrawer, openAttach, openVoice }: { start: (v?: string) => void; openDrawer: () => void; openAttach: () => void; openVoice: () => void }) {
  return <div className="screen">
    <AppHeader onMenu={openDrawer} onNew={() => start()} />
    <main className="home-main">
      <div className="welcome">
        <Logo />
        <h1>Que souhaites-tu acheter,<br />vendre ou faire réaliser&nbsp;?</h1>
        <p>Exprime simplement ton besoin.<br />Trezutil s’occupe du reste.</p>
      </div>
      <div className="suggestions">
        <button onClick={() => start('Trouve-moi un fournisseur fiable')}><Icon name="search" size={17} />Trouver un fournisseur</button>
        <button onClick={() => start('Je souhaite comparer plusieurs offres')}><Icon name="briefcase" size={17} />Comparer des offres</button>
        <button onClick={() => start('Aide-moi à négocier un meilleur prix')}><Icon name="credit" size={17} />Négocier un prix</button>
      </div>
      <div className="partners" aria-label="Partenaires"><span>VISA</span><span>stripe</span><span>DHL</span><span>ORANGE</span></div>
    </main>
    <Composer onSend={start} onAttach={openAttach} onVoice={openVoice} generating={false} stop={() => {}} />
  </div>;
}

function ProgressStep({ done, active, children }: { done?: boolean; active?: boolean; children: React.ReactNode }) {
  return <div className={`progress-step ${done ? 'done' : ''} ${active ? 'active' : ''}`}>
    <span>{done ? <Icon name="check" size={13} /> : active ? <i /> : ''}</span><p>{children}</p>
  </div>;
}

function OfferCard({ featured = false, onCompare }: { featured?: boolean; onCompare?: () => void }) {
  return <article className={`offer-card ${featured ? 'featured' : ''}`}>
    <div className="offer-top">
      <div className="supplier-logo">{featured ? 'K' : 'A'}</div>
      <div><strong>{featured ? 'Kawa Pro Sénégal' : 'Atlas Café Services'}</strong><p><Icon name="shield" size={13} /> Fournisseur vérifié</p></div>
      {featured && <span className="best">Meilleur choix</span>}
    </div>
    <div className="offer-body">
      <p className="offer-name">Café arabica premium · 20 kg/mois</p>
      <div className="offer-price"><strong>{featured ? '148 000' : '156 500'} F CFA</strong><span>/ mois</span></div>
      <div className="offer-meta"><span>Livraison incluse</span><span>Disponible</span></div>
    </div>
    <button onClick={onCompare}>{featured ? 'Voir la proposition' : 'Ajouter au comparatif'}<Icon name="chevron" size={16} /></button>
  </article>;
}

function Conversation({ initial, openDrawer, openAttach, openVoice, onCompare }: { initial: string; openDrawer: () => void; openAttach: () => void; openVoice: () => void; onCompare: () => void }) {
  const [generating, setGenerating] = useState(false);
  const [showResults, setShowResults] = useState(true);
  const [messages, setMessages] = useState([initial || 'Je cherche un fournisseur de café pour nos bureaux à Dakar. Environ 20 kg par mois.']);
  const bottomRef = useRef<HTMLDivElement>(null);
  const send = (text: string) => {
    setMessages(m => [...m, text]);
    setGenerating(true);
    setShowResults(false);
    window.setTimeout(() => { setGenerating(false); setShowResults(true); }, 1600);
  };
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages, generating, showResults]);
  return <div className="screen">
    <AppHeader onMenu={openDrawer} onNew={() => { setMessages([]); setShowResults(false); }} />
    <main className="conversation">
      <div className="user-message">{messages[0]}</div>
      <div className="assistant-message">
        <div className="assistant-mark"><Logo small /></div>
        <div>
          <p>Je vais rechercher des fournisseurs adaptés, vérifier leurs conditions et comparer les offres disponibles.</p>
          <div className="progress-list">
            <ProgressStep done>Besoin analysé</ProgressStep>
            <ProgressStep done>8 fournisseurs consultés</ProgressStep>
            <ProgressStep active={generating}>{generating ? 'Analyse des propositions…' : '3 offres pertinentes identifiées'}</ProgressStep>
          </div>
        </div>
      </div>
      {showResults && <div className="assistant-message results">
        <div className="assistant-mark"><Logo small /></div>
        <div className="result-content">
          <p>J’ai retenu <strong>3 propositions</strong>. Celle de Kawa Pro offre le meilleur équilibre entre prix, régularité et délai de livraison.</p>
          <OfferCard featured onCompare={onCompare} />
          <button className="text-action" onClick={onCompare}>Comparer les 3 offres <Icon name="chevron" size={15} /></button>
          <div className="message-actions"><button><Icon name="check" size={16} /></button><button><Icon name="archive" size={16} /></button><button><Icon name="more" size={17} /></button></div>
        </div>
      </div>}
      {messages.slice(1).map((m, i) => <div className="user-message" key={i}>{m}</div>)}
      {generating && <div className="thinking"><Logo small /><span /><span /><span /></div>}
      <div ref={bottomRef} />
    </main>
    <Composer onSend={send} onAttach={openAttach} onVoice={openVoice} generating={generating} stop={() => setGenerating(false)} />
  </div>;
}

function Drawer({ close, go }: { close: () => void; go: (s: Screen) => void }) {
  const [menuFor, setMenuFor] = useState<number | null>(null);
  return <div className="drawer-layer">
    <button className="scrim" onClick={close} aria-label="Fermer" />
    <aside className="drawer">
      <div className="drawer-top"><Logo small /><button className="icon-btn" onClick={close}><Icon name="close" /></button></div>
      <button className="new-chat" onClick={() => go('home')}><Icon name="edit" size={19} />Nouvelle conversation</button>
      <button className="drawer-search" onClick={() => go('search')}><Icon name="search" size={19} /><span>Rechercher</span><kbd>⌘ K</kbd></button>
      <div className="history">
        {['Aujourd’hui', '7 derniers jours'].map(section => <div key={section}>
          <p className="history-label">{section}</p>
          {conversations.filter(c => c[1] === section).map((c, i) => {
            const index = conversations.indexOf(c);
            return <div className="history-item" key={c[0]}>
              <button onClick={() => go('conversation')}>{c[0]}</button>
              <button onClick={() => setMenuFor(menuFor === index ? null : index)}><Icon name="more" size={18} /></button>
              {menuFor === index && <div className="item-menu">
                <button><Icon name="edit" size={16} />Renommer</button>
                <button><Icon name="archive" size={16} />Archiver</button>
                <button className="danger"><Icon name="trash" size={16} />Supprimer</button>
              </div>}
            </div>;
          })}
        </div>)}
      </div>
      <div className="drawer-bottom">
        <button onClick={() => go('profile')}><span className="avatar">AM</span><span><strong>Amadou Mbaye</strong><small>2 480 crédits</small></span><Icon name="more" size={19} /></button>
      </div>
    </aside>
  </div>;
}

function SearchScreen({ back, goConversation }: { back: () => void; goConversation: () => void }) {
  const [query, setQuery] = useState('');
  return <div className="screen"><AppHeader title="Rechercher" back={back} />
    <main className="subscreen search-screen">
      <div className="search-field"><Icon name="search" size={19} /><input autoFocus placeholder="Rechercher dans les conversations" value={query} onChange={e => setQuery(e.target.value)} />{query && <button onClick={() => setQuery('')}><Icon name="close" size={16} /></button>}</div>
      <p className="section-label">{query ? 'Résultats' : 'Récents'}</p>
      <div className="list">
        {conversations.filter(c => c[0].toLowerCase().includes(query.toLowerCase())).map(c => <button className="conversation-row" key={c[0]} onClick={goConversation}><span className="row-icon"><Icon name="edit" size={18} /></span><span><strong>{c[0]}</strong><small>{c[1]}</small></span><Icon name="chevron" size={17} /></button>)}
      </div>
    </main>
  </div>;
}

const ListRow = ({ icon, title, detail, onClick, accent }: { icon: IconName; title: string; detail?: string; onClick?: () => void; accent?: boolean }) =>
  <button className={`list-row ${accent ? 'accent' : ''}`} onClick={onClick}><span className="row-icon"><Icon name={icon} size={19} /></span><span><strong>{title}</strong>{detail && <small>{detail}</small>}</span>{onClick && <Icon name="chevron" size={17} />}</button>;

function Profile({ back, go }: { back: () => void; go: (s: Screen) => void }) {
  return <div className="screen"><AppHeader title="Profil" back={back} /><main className="subscreen profile-screen">
    <div className="profile-hero"><div className="big-avatar">AM</div><h2>Amadou Mbaye</h2><p>amadou@example.com</p><span>Compte vérifié</span></div>
    <div className="group"><ListRow icon="credit" title="Crédits personnels" detail="2 480 crédits disponibles" onClick={() => go('credits')} accent /><ListRow icon="briefcase" title="Mes missions" detail="3 en cours" onClick={() => go('missions')} /><ListRow icon="bell" title="Notifications" detail="2 nouvelles" onClick={() => go('notifications')} /></div>
    <div className="group"><ListRow icon="settings" title="Paramètres" onClick={() => go('settings')} /><ListRow icon="help" title="Aide et assistance" onClick={() => {}} /></div>
    <div className="group"><ListRow icon="logout" title="Se déconnecter" /></div>
    <p className="version">Trezutil pour mobile · Version 1.0</p>
  </main></div>;
}

function Settings({ back, platform, setPlatform }: { back: () => void; platform: 'ios' | 'android'; setPlatform: (p: 'ios' | 'android') => void }) {
  const [notifications, setNotifications] = useState(true);
  const [haptics, setHaptics] = useState(true);
  return <div className="screen"><AppHeader title="Paramètres" back={back} /><main className="subscreen settings-screen">
    <p className="section-label">APPARENCE ET APPAREIL</p>
    <div className="group">
      <div className="setting-row"><span className="row-icon"><Icon name="phone" size={19} /></span><span><strong>Plateforme</strong><small>Adapter les conventions visuelles</small></span><div className="mini-segment"><button className={platform === 'ios' ? 'selected' : ''} onClick={() => setPlatform('ios')}>iOS</button><button className={platform === 'android' ? 'selected' : ''} onClick={() => setPlatform('android')}>Android</button></div></div>
      <ListRow icon="globe" title="Langue" detail="Français" onClick={() => {}} />
    </div>
    <p className="section-label">PRÉFÉRENCES</p>
    <div className="group">
      <ToggleRow title="Notifications" detail="Missions, offres et commandes" value={notifications} setValue={setNotifications} />
      <ToggleRow title="Retour haptique" detail="Réactions tactiles discrètes" value={haptics} setValue={setHaptics} />
    </div>
    <p className="section-label">CONFIDENTIALITÉ</p>
    <div className="group"><ListRow icon="shield" title="Données et confidentialité" onClick={() => {}} /><ListRow icon="archive" title="Conversations archivées" onClick={() => {}} /></div>
  </main></div>;
}

function ToggleRow({ title, detail, value, setValue }: { title: string; detail: string; value: boolean; setValue: (v: boolean) => void }) {
  return <div className="setting-row"><span><strong>{title}</strong><small>{detail}</small></span><button className={`toggle ${value ? 'on' : ''}`} onClick={() => setValue(!value)}><i /></button></div>;
}

function Credits({ back }: { back: () => void }) {
  return <div className="screen"><AppHeader title="Crédits" back={back} /><main className="subscreen credits-screen">
    <div className="credit-card"><p>Solde disponible</p><h2>2 480</h2><span>crédits personnels</span><button>Ajouter des crédits</button></div>
    <div className="credit-note"><Icon name="shield" size={18} /><p>Les crédits sont utilisés uniquement après votre confirmation pour les opérations commerciales.</p></div>
    <h3>Activité récente</h3>
    <div className="group transactions">
      <div><span className="transaction-icon">+</span><p><strong>Recharge de crédits</strong><small>18 juin 2025</small></p><b className="positive">+ 2 000</b></div>
      <div><span className="transaction-icon"><Icon name="search" size={16} /></span><p><strong>Recherche fournisseurs</strong><small>17 juin 2025</small></p><b>− 20</b></div>
      <div><span className="transaction-icon"><Icon name="briefcase" size={16} /></span><p><strong>Négociation assistée</strong><small>14 juin 2025</small></p><b>− 100</b></div>
    </div>
  </main></div>;
}

function Comparison({ back, setStage }: { back: () => void; setStage: (v: 'compare' | 'negotiation' | 'confirmed') => void }) {
  return <div className="screen"><AppHeader title="Comparaison" back={back} /><main className="subscreen compare-screen">
    <div className="demo-label">DONNÉES DE DÉMONSTRATION</div>
    <h2>3 offres de café</h2><p className="muted">Pour 20 kg par mois · Livraison à Dakar</p>
    <div className="score-card">
      <div className="score-head"><span className="supplier-logo">K</span><div><small>RECOMMANDÉ</small><strong>Kawa Pro Sénégal</strong></div><b>9,2<small>/10</small></b></div>
      <div className="score-grid"><span><small>Prix</small><strong>148 000 F</strong></span><span><small>Livraison</small><strong>48 h</strong></span><span><small>Engagement</small><strong>3 mois</strong></span></div>
      <div className="why"><Icon name="check" size={16} />Meilleur prix et livraison la plus rapide</div>
      <button onClick={() => setStage('negotiation')}>Négocier cette offre</button>
    </div>
    <OfferCard />
    <div className="compact-offer"><span className="supplier-logo">S</span><div><strong>Sahel Distribution</strong><p>162 000 F CFA · Livraison 72 h</p></div><Icon name="chevron" size={17} /></div>
  </main></div>;
}

function Negotiation({ back, done }: { back: () => void; done: () => void }) {
  const [active, setActive] = useState(false);
  return <div className="screen"><AppHeader title="Négociation" back={back} /><main className="subscreen negotiation-screen">
    <div className="supplier-summary"><span className="supplier-logo">K</span><div><strong>Kawa Pro Sénégal</strong><small>Offre n° TRZ-2048 · Fictive</small></div><span className="status">EN COURS</span></div>
    <div className="timeline">
      <div className="timeline-item done"><i><Icon name="check" size={13} /></i><div><small>10:32</small><strong>Offre initiale reçue</strong><p>148 000 F CFA / mois</p></div></div>
      <div className="timeline-item done"><i><Icon name="check" size={13} /></i><div><small>10:34</small><strong>Contre-proposition envoyée</strong><p>Engagement 6 mois contre une remise de 8 %.</p></div></div>
      <div className={`timeline-item ${active ? 'done' : 'active'}`}><i>{active ? <Icon name="check" size={13} /> : ''}</i><div><small>MAINTENANT</small><strong>{active ? 'Nouvelle offre reçue' : 'Négociation en cours…'}</strong><p>{active ? 'Le fournisseur accepte une remise de 6 %.' : 'Trezutil échange avec le fournisseur.'}</p></div></div>
    </div>
    {!active ? <button className="primary-btn" onClick={() => setActive(true)}>Simuler la réponse</button> : <div className="final-offer"><span>Nouvelle proposition</span><h2>139 120 F CFA</h2><p>Économie de 8 880 F CFA par mois</p><button onClick={done}>Accepter et continuer</button></div>}
    <button className="secondary-btn">Arrêter la négociation</button>
  </main></div>;
}

function Confirmation({ back, home }: { back: () => void; home: () => void }) {
  return <div className="screen"><AppHeader title="Confirmation" back={back} /><main className="confirmation-screen">
    <div className="success-mark"><Icon name="check" size={30} /></div><h1>Commande confirmée</h1><p>Votre commande fictive a bien été enregistrée auprès de Kawa Pro Sénégal.</p>
    <div className="receipt"><div><span>Référence</span><strong>TRZ-2048</strong></div><div><span>Montant mensuel</span><strong>139 120 F CFA</strong></div><div><span>Première livraison</span><strong>20 juin 2025</strong></div></div>
    <button className="primary-btn" onClick={home}>Revenir à l’accueil</button><button className="secondary-btn">Voir la mission</button>
  </main></div>;
}

function Voice({ close }: { close: () => void }) {
  const [muted, setMuted] = useState(false);
  const [state, setState] = useState<'listen' | 'think' | 'speak'>('listen');
  useEffect(() => {
    const id = window.setInterval(() => setState(s => s === 'listen' ? 'think' : s === 'think' ? 'speak' : 'listen'), 2200);
    return () => window.clearInterval(id);
  }, []);
  return <div className="voice-screen">
    <div className="voice-top"><span>Conversation vocale</span><button onClick={close}><Icon name="close" /></button></div>
    <div className={`orb ${state}`}><i /><i /><i /><i /></div>
    <div className="voice-copy"><h2>{state === 'listen' ? 'Je vous écoute' : state === 'think' ? 'Je réfléchis…' : 'Trezutil répond'}</h2><p>{state === 'listen' ? 'Parlez naturellement de votre besoin.' : state === 'think' ? 'Analyse de votre demande commerciale.' : '« J’ai trouvé plusieurs options adaptées… »'}</p></div>
    <div className="voice-controls"><button className={muted ? 'muted' : ''} onClick={() => setMuted(!muted)}><Icon name="mic" /><span>{muted ? 'Réactiver' : 'Micro'}</span></button><button className="end-call" onClick={close}><Icon name="close" /><span>Terminer</span></button></div>
  </div>;
}

function AttachmentSheet({ close }: { close: () => void }) {
  return <div className="sheet-layer"><button className="scrim" onClick={close} /><div className="bottom-sheet"><div className="handle" /><h3>Ajouter à la conversation</h3>
    <button><span className="sheet-icon"><Icon name="camera" /></span><span><strong>Prendre une photo</strong><small>Utiliser l’appareil photo</small></span></button>
    <button><span className="sheet-icon"><Icon name="image" /></span><span><strong>Photos</strong><small>Choisir dans la photothèque</small></span></button>
    <button><span className="sheet-icon"><Icon name="file" /></span><span><strong>Fichiers</strong><small>PDF, document ou tableur</small></span></button>
    <p>Formats acceptés : PDF, DOCX, XLSX, JPG et PNG</p>
  </div></div>;
}

function SimpleListScreen({ screen, back }: { screen: 'missions' | 'notifications'; back: () => void }) {
  const missions = [['Négociation Kawa Pro', 'En cours · Mise à jour il y a 2 min'], ['Devis mobilier bureau', '3 propositions reçues'], ['Réservation salle Dakar', 'Terminée · 12 juin 2025']];
  const notifications = [['Nouvelle offre reçue', 'Kawa Pro a répondu à votre demande.', '2 min'], ['Comparatif prêt', '3 imprimeurs correspondent à vos critères.', '1 h'], ['Mission terminée', 'Votre réservation est confirmée.', 'Hier']];
  return <div className="screen"><AppHeader title={screen === 'missions' ? 'Missions' : 'Notifications'} back={back} /><main className="subscreen">
    {screen === 'missions' ? <><div className="filter-tabs"><button className="active">Toutes</button><button>En cours</button><button>Terminées</button></div><div className="group">{missions.map((m, i) => <ListRow key={m[0]} icon={i === 2 ? 'check' : 'briefcase'} title={m[0]} detail={m[1]} onClick={() => {}} />)}</div></> :
    <div className="notification-list">{notifications.map((n, i) => <button key={n[0]}><span className={`notification-icon ${i < 2 ? 'unread' : ''}`}><Icon name={i === 2 ? 'check' : 'bell'} size={18} /></span><span><strong>{n[0]}</strong><p>{n[1]}</p><small>{n[2]}</small></span></button>)}</div>}
  </main></div>;
}

function Auth({ close }: { close: () => void }) {
  return <div className="screen auth-screen"><button className="auth-close" onClick={close}><Icon name="close" /></button><div className="auth-content"><Logo /><h1>Bienvenue sur Trezutil</h1><p>Votre assistant pour acheter, vendre et faire réaliser simplement.</p>
    <button className="google-btn"><b>G</b>Continuer avec Google</button><div className="or"><span />ou<span /></div><button className="phone-btn"><Icon name="phone" size={19} />Continuer avec un numéro</button>
    <small>En continuant, vous acceptez les Conditions d’utilisation et la Politique de confidentialité.</small>
  </div></div>;
}

export default function App() {
  const [screen, setScreen] = useState<Screen>('home');
  const [previous, setPrevious] = useState<Screen>('home');
  const [drawer, setDrawer] = useState(false);
  const [attachment, setAttachment] = useState(false);
  const [initial, setInitial] = useState('');
  const [platform, setPlatform] = useState<'ios' | 'android'>('ios');
  const [commerceStage, setCommerceStage] = useState<'none' | 'compare' | 'negotiation' | 'confirmed'>('none');
  const navigate = (s: Screen) => { setPrevious(screen); setScreen(s); setDrawer(false); };
  const start = (text = '') => { setInitial(text); navigate('conversation'); };
  const back = () => setScreen(previous === screen ? 'home' : previous);
  const openCompare = () => setCommerceStage('compare');

  let content: React.ReactNode;
  if (commerceStage === 'compare') content = <Comparison back={() => setCommerceStage('none')} setStage={setCommerceStage} />;
  else if (commerceStage === 'negotiation') content = <Negotiation back={() => setCommerceStage('compare')} done={() => setCommerceStage('confirmed')} />;
  else if (commerceStage === 'confirmed') content = <Confirmation back={() => setCommerceStage('negotiation')} home={() => { setCommerceStage('none'); setScreen('home'); }} />;
  else if (screen === 'home') content = <Home start={start} openDrawer={() => setDrawer(true)} openAttach={() => setAttachment(true)} openVoice={() => navigate('voice')} />;
  else if (screen === 'conversation') content = <Conversation initial={initial} openDrawer={() => setDrawer(true)} openAttach={() => setAttachment(true)} openVoice={() => navigate('voice')} onCompare={openCompare} />;
  else if (screen === 'search') content = <SearchScreen back={back} goConversation={() => navigate('conversation')} />;
  else if (screen === 'profile') content = <Profile back={back} go={navigate} />;
  else if (screen === 'settings') content = <Settings back={back} platform={platform} setPlatform={setPlatform} />;
  else if (screen === 'credits') content = <Credits back={back} />;
  else if (screen === 'voice') content = <Voice close={back} />;
  else if (screen === 'missions' || screen === 'notifications') content = <SimpleListScreen screen={screen} back={back} />;
  else content = <Auth close={back} />;

  return <div className="prototype-stage">
    <div className="prototype-tools">
      <div><Logo small /><span><strong>Trezutil Mobile</strong><small>Prototype interactif</small></span></div>
      <div className="platform-switch"><button className={platform === 'ios' ? 'active' : ''} onClick={() => setPlatform('ios')}>iOS</button><button className={platform === 'android' ? 'active' : ''} onClick={() => setPlatform('android')}>Android</button></div>
      <button className="preview-login" onClick={() => navigate('auth')}>Voir la connexion</button>
    </div>
    <div className={`device ${platform}`}>
      <div className="status-bar"><span>9:41</span><div className="island" /><div><span className="signal">▮▮▮</span><Icon name="wifi" size={14} /><span className="battery" /></div></div>
      {content}
      <div className="home-indicator" />
      {drawer && <Drawer close={() => setDrawer(false)} go={navigate} />}
      {attachment && <AttachmentSheet close={() => setAttachment(false)} />}
    </div>
  </div>;
}
