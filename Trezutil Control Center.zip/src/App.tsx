import { useMemo, useState } from 'react'

type IconName =
  | 'grid' | 'pulse' | 'alert' | 'box' | 'layers' | 'tag' | 'building' | 'shield'
  | 'users' | 'target' | 'search' | 'compare' | 'quote' | 'message' | 'cart'
  | 'calendar' | 'briefcase' | 'spark' | 'brain' | 'bot' | 'route' | 'clock'
  | 'coins' | 'card' | 'receipt' | 'book' | 'trend' | 'plug' | 'send' | 'key'
  | 'toggle' | 'settings' | 'globe' | 'bell' | 'lock' | 'chart' | 'server'
  | 'database' | 'terminal' | 'chevron' | 'plus' | 'more' | 'filter' | 'download'
  | 'check' | 'arrow' | 'close' | 'menu' | 'command'

const paths: Record<IconName, React.ReactNode> = {
  grid: <><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></>,
  pulse: <path d="M3 12h4l2.2-6 4.2 12 2.3-6H21"/>, alert: <><path d="M12 3 2.8 19h18.4L12 3Z"/><path d="M12 9v4m0 3h.01"/></>,
  box: <><path d="m4 7 8-4 8 4-8 4-8-4Z"/><path d="m4 7v10l8 4 8-4V7M12 11v10"/></>,
  layers: <><path d="m12 2 9 5-9 5-9-5 9-5Z"/><path d="m3 12 9 5 9-5M3 17l9 5 9-5"/></>,
  tag: <><path d="M20 13 13 20l-9-9V4h7l9 9Z"/><path d="M8.5 8.5h.01"/></>,
  building: <><path d="M4 21V5l8-3 8 3v16M8 9h1m6 0h1M8 13h1m6 0h1M8 17h1m6 0h1M2 21h20"/></>,
  shield: <><path d="M12 22s8-3 8-10V5l-8-3-8 3v7c0 7 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/></>,
  users: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></>,
  target: <><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/></>,
  search: <><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></>,
  compare: <><path d="M7 4h10M7 4l3-3M7 4l3 3M17 20H7m10 0-3-3m3 3-3 3"/></>,
  quote: <><path d="M4 6h16v12H4z"/><path d="M8 10h8m-8 4h5"/></>,
  message: <><path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4v8Z"/><path d="M8 9h8m-8 4h5"/></>,
  cart: <><circle cx="9" cy="20" r="1"/><circle cx="19" cy="20" r="1"/><path d="M3 3h2l2.4 11.5a2 2 0 0 0 2 1.5H18a2 2 0 0 0 2-1.6L21 7H6"/></>,
  calendar: <><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/></>,
  briefcase: <><rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 7V4h8v3m-4 4v5M3 12h18"/></>,
  spark: <path d="m12 3 1.6 5.4L19 10l-5.4 1.6L12 17l-1.6-5.4L5 10l5.4-1.6L12 3Zm7 13 .7 2.3L22 19l-2.3.7L19 22l-.7-2.3L16 19l2.3-.7L19 16Z"/>,
  brain: <><path d="M9.5 4.5A3.5 3.5 0 0 0 6 8v.3A3.5 3.5 0 0 0 4 14a3.5 3.5 0 0 0 5.5 4.2V4.5ZM14.5 4.5A3.5 3.5 0 0 1 18 8v.3a3.5 3.5 0 0 1 2 5.7 3.5 3.5 0 0 1-5.5 4.2V4.5Z"/><path d="M9.5 9H7m7.5 3H17M9.5 15H7m7.5-7H17"/></>,
  bot: <><rect x="4" y="7" width="16" height="12" rx="3"/><path d="M12 3v4M8 12h.01M16 12h.01M8 16h8"/></>,
  route: <><circle cx="5" cy="5" r="2"/><circle cx="19" cy="19" r="2"/><path d="M7 5h5a3 3 0 0 1 3 3v8a3 3 0 0 0 3 3"/></>,
  clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
  coins: <><ellipse cx="9" cy="6" rx="6" ry="3"/><path d="M3 6v8c0 1.7 2.7 3 6 3m0-7c-3.3 0-6-1.3-6-3"/><path d="M9 12c0 1.7 2.7 3 6 3s6-1.3 6-3  -2.7-3-6-3-6 1.3-6 3Zm0 0v6c0 1.7 2.7 3 6 3s6-1.3 6-3v-6"/></>,
  card: <><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20M6 15h4"/></>,
  receipt: <path d="M6 3h12v19l-3-2-3 2-3-2-3 2V3Zm3 5h6m-6 4h6m-6 4h4"/>,
  book: <><path d="M4 3h13a3 3 0 0 1 3 3v15H7a3 3 0 0 1-3-3V3Z"/><path d="M4 17a3 3 0 0 1 3-3h13"/></>,
  trend: <><path d="M3 17 9 11l4 4 8-9"/><path d="M15 6h6v6"/></>,
  plug: <><path d="m8 12 8-8m-7 1 10 10M5 9l-2 2a5 5 0 0 0 7 7l2-2m0-4-4 4"/></>,
  send: <><path d="m22 2-7 20-4-9-9-4 20-7Z"/><path d="M22 2 11 13"/></>,
  key: <><circle cx="8" cy="15" r="4"/><path d="m11 12 9-9m-2 2 3 3m-6 0 3 3"/></>,
  toggle: <><rect x="2" y="7" width="20" height="10" rx="5"/><circle cx="16" cy="12" r="3"/></>,
  settings: <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.8 1.8 0 0 0 .4 2l.1.1-2.8 2.8-.1-.1a1.8 1.8 0 0 0-2-.4 1.8 1.8 0 0 0-1.1 1.6v.2h-4V21A1.8 1.8 0 0 0 8.8 19.4a1.8 1.8 0 0 0-2 .4l-.1.1-2.8-2.8L4 17a1.8 1.8 0 0 0 .4-2A1.8 1.8 0 0 0 2.8 14h-.2v-4h.2A1.8 1.8 0 0 0 4.4 9a1.8 1.8 0 0 0-.4-2l-.1-.1 2.8-2.8.1.1a1.8 1.8 0 0 0 2 .4A1.8 1.8 0 0 0 10 3v-.2h4V3a1.8 1.8 0 0 0 1 1.6 1.8 1.8 0 0 0 2-.4l.1-.1 2.8 2.8-.1.1a1.8 1.8 0 0 0-.4 2 1.8 1.8 0 0 0 1.6 1h.2v4H21a1.8 1.8 0 0 0-1.6 1Z"/></>,
  globe: <><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></>,
  bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></>,
  lock: <><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></>,
  chart: <><path d="M4 20V10m5 10V4m6 16v-7m5 7V7"/></>,
  server: <><rect x="3" y="3" width="18" height="7" rx="2"/><rect x="3" y="14" width="18" height="7" rx="2"/><path d="M7 6.5h.01M7 17.5h.01"/></>,
  database: <><ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v7c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 12v7c0 1.7 3.6 3 8 3s8-1.3 8-3v-7"/></>,
  terminal: <><rect x="3" y="4" width="18" height="16" rx="2"/><path d="m7 9 3 3-3 3m6 0h4"/></>,
  chevron: <path d="m9 18 6-6-6-6"/>, plus: <path d="M12 5v14M5 12h14"/>,
  more: <><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></>,
  filter: <path d="M3 5h18l-7 8v6l-4 2v-8L3 5Z"/>, download: <path d="M12 3v12m0 0 5-5m-5 5-5-5M4 21h16"/>,
  check: <path d="m5 12 4 4L19 6"/>, arrow: <path d="M5 12h14m-5-5 5 5-5 5"/>,
  close: <path d="m6 6 12 12M18 6 6 18"/>, menu: <path d="M4 7h16M4 12h16M4 17h16"/>,
  command: <><rect x="3" y="3" width="18" height="18" rx="5"/><path d="M8 12h8M12 8v8"/></>,
}

function Icon({ name, size = 18 }: { name: IconName; size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden>{paths[name]}</svg>
}

const navigation: { group: string; items: { label: string; icon: IconName }[] }[] = [
  { group: 'Overview', items: [{ label: 'Command Center', icon: 'grid' }, { label: 'Activité en temps réel', icon: 'pulse' }, { label: 'Alertes et incidents', icon: 'alert' }] },
  { group: 'Commerce Management', items: [{ label: 'Services', icon: 'box' }, { label: 'Catalogue interne', icon: 'layers' }, { label: 'Catégories et secteurs', icon: 'tag' }, { label: 'Fournisseurs', icon: 'building' }, { label: 'Vérification fournisseurs', icon: 'shield' }, { label: 'Clients et organisations', icon: 'users' }] },
  { group: 'Commerce Operations', items: [{ label: 'Intentions commerciales', icon: 'target' }, { label: 'Recherches', icon: 'search' }, { label: 'Comparaisons', icon: 'compare' }, { label: 'Demandes de devis', icon: 'quote' }, { label: 'Négociations', icon: 'message' }, { label: 'Commandes', icon: 'cart' }, { label: 'Réservations', icon: 'calendar' }, { label: 'Missions & litiges', icon: 'briefcase' }] },
  { group: 'AI & Intelligence', items: [{ label: 'AI Control Center', icon: 'spark' }, { label: 'Modèles & fournisseurs', icon: 'brain' }, { label: 'Agents & prompts', icon: 'bot' }, { label: 'Routage intelligent', icon: 'route' }, { label: 'Historique des exécutions', icon: 'clock' }] },
  { group: 'Credits & Revenue', items: [{ label: 'Crédits & facturation', icon: 'coins' }, { label: 'Plans et abonnements', icon: 'card' }, { label: 'Transactions', icon: 'receipt' }, { label: 'Ledger / Grand livre', icon: 'book' }, { label: 'Revenus & commissions', icon: 'trend' }] },
  { group: 'Integrations', items: [{ label: 'Integrations Center', icon: 'plug' }, { label: 'Canaux & paiements', icon: 'send' }, { label: 'Webhooks & secrets', icon: 'key' }] },
  { group: 'Platform', items: [{ label: 'Fonctionnalités & modules', icon: 'toggle' }, { label: 'Configuration plateforme', icon: 'settings' }, { label: 'Géographie & langues', icon: 'globe' }, { label: 'Notifications', icon: 'bell' }] },
  { group: 'Security & Governance', items: [{ label: 'Administrateurs & rôles', icon: 'lock' }, { label: 'Journal d’audit', icon: 'book' }] },
  { group: 'Analytics', items: [{ label: 'Analytics & rapports', icon: 'chart' }] },
  { group: 'System', items: [{ label: 'Santé des services', icon: 'server' }, { label: 'Infrastructure & données', icon: 'database' }, { label: 'Logs & sauvegardes', icon: 'terminal' }] },
]

const serviceRows = [
  { name: 'Recherche de fournisseurs', code: 'supplier_discovery', category: 'Sourcing', status: 'Actif', executions: '12 840', success: '94,8 %', credits: '8–24' },
  { name: 'Négociation commerciale', code: 'commercial_negotiation', category: 'Commerce assisté', status: 'Actif', executions: '8 216', success: '87,2 %', credits: '18–60' },
  { name: 'Demande de devis', code: 'quote_request', category: 'Procurement', status: 'Actif', executions: '6 404', success: '91,1 %', credits: '12' },
  { name: 'Approvisionnement entreprise', code: 'business_procurement', category: 'B2B', status: 'Pilote', executions: '1 057', success: '82,6 %', credits: '40–120' },
  { name: 'Organisation d’événements', code: 'event_planning', category: 'Services', status: 'Brouillon', executions: '—', success: '—', credits: 'À définir' },
]

const suppliers = [
  { name: 'Atlas Industrial Supply', id: 'SUP-02841', sector: 'Équipements industriels', country: 'Maroc', status: 'Verified', score: 96, volume: '€284 600' },
  { name: 'Nexa Logistics SARL', id: 'SUP-02904', sector: 'Transport & logistique', country: 'Sénégal', status: 'Under Review', score: 81, volume: '€92 400' },
  { name: 'Kora Office Solutions', id: 'SUP-02712', sector: 'Fournitures B2B', country: 'Côte d’Ivoire', status: 'Documents Submitted', score: 74, volume: '€48 120' },
  { name: 'Meridian Hospitality', id: 'SUP-02508', sector: 'Hôtellerie', country: 'France', status: 'Verified', score: 91, volume: '€175 800' },
  { name: 'Volta Energy Systems', id: 'SUP-03012', sector: 'Énergie', country: 'Ghana', status: 'Registered', score: 62, volume: '—' },
]

function Status({ children, tone }: { children: React.ReactNode; tone?: 'good' | 'warn' | 'bad' | 'info' | 'neutral' }) {
  const inferred = tone || (String(children).includes('Actif') || String(children).includes('Verified') || String(children).includes('Operational') ? 'good' : String(children).includes('Review') || String(children).includes('Submitted') || String(children).includes('Pilote') ? 'warn' : 'neutral')
  return <span className={`status ${inferred}`}><span />{children}</span>
}

function Sparkline({ points = '0,28 14,26 28,27 42,20 56,22 70,13 84,16 100,7' }: { points?: string }) {
  return <svg className="sparkline" viewBox="0 0 100 34" preserveAspectRatio="none"><path d={`M${points.replaceAll(' ', ' L')}`} fill="none" stroke="currentColor" strokeWidth="2"/><path d={`M${points.replaceAll(' ', ' L')} L100 34 L0 34 Z`} fill="currentColor" opacity=".07"/></svg>
}

function PageHeader({ eyebrow, title, description, action, onAction }: { eyebrow: string; title: string; description: string; action?: string; onAction?: () => void }) {
  return <div className="page-head">
    <div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{description}</p></div>
    <div className="head-actions"><button className="icon-btn"><Icon name="more"/></button>{action && <button className="primary" onClick={onAction}><Icon name="plus" size={16}/>{action}</button>}</div>
  </div>
}

function Dashboard() {
  const stats = [
    ['Volume transactionnel', '€2,48 M', '+12,4 %', 'trend'],
    ['Intentions commerciales', '18 429', '+8,1 %', 'target'],
    ['Négociations actives', '286', '42 à surveiller', 'message'],
    ['Revenus nets', '€184,2 k', '+16,8 %', 'coins'],
    ['Crédits consommés', '1,28 M', '+6,2 %', 'spark'],
    ['Coûts IA', '€21,8 k', '8,8 % du CA', 'brain'],
  ] as const
  return <>
    <PageHeader eyebrow="Overview / Command Center" title="Bonjour, Amine" description="Voici ce qui demande votre attention sur la plateforme aujourd’hui." action="Action rapide"/>
    <div className="notice"><div className="notice-icon"><Icon name="alert"/></div><div><strong>3 interventions requises</strong><span>Deux intégrations rencontrent des erreurs et 14 fournisseurs attendent une décision depuis plus de 48 h.</span></div><button>Examiner les alertes <Icon name="arrow" size={15}/></button></div>
    <div className="metric-grid">{stats.map(([label, value, delta, icon], i) => <div className="metric" key={label}><div className="metric-top"><span>{label}</span><Icon name={icon}/></div><div className="metric-main"><strong>{value}</strong><span className={i === 2 ? 'amber-text' : ''}>{delta}</span></div><Sparkline points={i % 2 ? '0,25 14,26 28,20 42,23 56,13 70,17 84,8 100,11' : undefined}/></div>)}</div>
    <div className="dashboard-grid">
      <section className="panel wide">
        <div className="panel-head"><div><h2>Flux commercial</h2><p>Performance sur les 30 derniers jours</p></div><select><option>30 derniers jours</option></select></div>
        <div className="funnel">
          {[['Intentions analysées','18 429','100%'],['Fournisseurs sollicités','11 860','64,4%'],['Offres qualifiées','7 204','39,1%'],['Commandes confirmées','2 816','15,3%']].map(([a,b,c],i)=><div className="funnel-item" key={a}><div className={`funnel-bar f${i}`}></div><div><span>{a}</span><strong>{b}</strong><small>{c} des intentions</small></div></div>)}
        </div>
        <div className="chart-legend"><span><i className="navy"/>Taux de conversion 15,3 %</span><span><i className="mint"/>Objectif 17,0 %</span><button>Voir l’analyse complète <Icon name="arrow" size={14}/></button></div>
      </section>
      <section className="panel">
        <div className="panel-head"><div><h2>À traiter</h2><p>Priorisé par impact</p></div><button className="text-btn">Tout voir</button></div>
        <div className="attention-list">
          <div><span className="attention-icon coral"><Icon name="plug"/></span><p><strong>Mobile Money — erreurs de paiement</strong><small>12 échecs sur les 60 dernières min.</small></p><Status tone="bad">Critique</Status></div>
          <div><span className="attention-icon amber"><Icon name="shield"/></span><p><strong>Vérifications en attente</strong><small>14 dossiers dépassent le SLA de 48 h.</small></p><span className="count">14</span></div>
          <div><span className="attention-icon blue"><Icon name="message"/></span><p><strong>Négociations bloquées</strong><small>7 mandats nécessitent une validation.</small></p><span className="count">7</span></div>
          <div><span className="attention-icon gray"><Icon name="brain"/></span><p><strong>Seuil de coût IA</strong><small>Le modèle reasoning atteint 82 % du budget.</small></p><span className="count">82%</span></div>
        </div>
      </section>
      <section className="panel wide">
        <div className="panel-head"><div><h2>Opérations récentes</h2><p>Activité commerciale en temps réel</p></div><button className="text-btn">Ouvrir l’activité live</button></div>
        <table><thead><tr><th>Opération</th><th>Service</th><th>Marché</th><th>Valeur</th><th>Statut</th></tr></thead><tbody>
          {[
            ['ORD-84921 · Soro Industries','Approvisionnement B2B','CI · Abidjan','€18 420','Commande confirmée'],
            ['NEG-28412 · Atlas Supply','Négociation commerciale','MA · Casablanca','€42 800','Contre-offre reçue'],
            ['RFQ-19308 · Lumina Hotels','Demande de devis','SN · Dakar','€9 760','Offres en analyse'],
            ['INT-68401 · A. Dupont','Recherche immobilière','FR · Lyon','€2 200/mois','Intention qualifiée'],
          ].map((r,i)=><tr key={r[0]}>{r.map((x,j)=><td key={x}>{j===0?<strong>{x}</strong>:j===4?<Status tone={i===0?'good':i===1?'warn':'info'}>{x}</Status>:x}</td>)}</tr>)}
        </tbody></table>
      </section>
      <section className="panel">
        <div className="panel-head"><div><h2>Santé de la plateforme</h2><p>Actualisé il y a 42 secondes</p></div><Status tone="good">99,98 % uptime</Status></div>
        <div className="health-list">{[['Commerce API','Operational','42 ms'],['Workflow Engine','Operational','68 ms'],['AI Orchestrator','Dégradé','184 ms'],['Payments','Operational','91 ms'],['Event Streaming','Operational','24 ms']].map(([a,b,c])=><div key={a}><span><i className={b==='Dégradé'?'warn-dot':''}/>{a}</span><small>{c}</small><Status tone={b==='Dégradé'?'warn':'good'}>{b}</Status></div>)}</div>
      </section>
    </div>
  </>
}

function Services({ openWizard }: { openWizard: () => void }) {
  const [search, setSearch] = useState('')
  const filtered = serviceRows.filter(x => x.name.toLowerCase().includes(search.toLowerCase()))
  return <>
    <PageHeader eyebrow="Commerce Management / Services" title="Services" description="Configurez les capacités commerciales que Trezutil peut exécuter pour ses utilisateurs." action="Nouveau service" onAction={openWizard}/>
    <div className="summary-strip"><div><span>Services actifs</span><strong>18</strong><small>sur 24 configurés</small></div><div><span>Exécutions ce mois</span><strong>31 642</strong><small className="positive">+11,8 %</small></div><div><span>Taux de réussite moyen</span><strong>91,4 %</strong><small>objectif 93 %</small></div><div><span>Revenus attribués</span><strong>€128,4 k</strong><small className="positive">+16,2 %</small></div></div>
    <section className="panel table-panel">
      <div className="table-toolbar"><div className="tabs"><button className="active">Tous <span>24</span></button><button>Actifs <span>18</span></button><button>Pilotes <span>3</span></button><button>Brouillons <span>3</span></button></div><div className="toolbar-actions"><label className="searchbox"><Icon name="search"/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Rechercher un service"/></label><button className="secondary"><Icon name="filter"/>Filtrer</button></div></div>
      <table className="data-table"><thead><tr><th><input type="checkbox"/></th><th>Service</th><th>Catégorie</th><th>Statut</th><th>Exécutions</th><th>Réussite</th><th>Crédits / action</th><th></th></tr></thead><tbody>{filtered.map((r,i)=><tr key={r.code}><td><input type="checkbox"/></td><td><div className="service-cell"><span className={`service-icon s${i}`}><Icon name={i===1?'message':i===2?'quote':i===3?'briefcase':'search'}/></span><div><strong>{r.name}</strong><small>{r.code}</small></div></div></td><td>{r.category}</td><td><Status>{r.status}</Status></td><td>{r.executions}</td><td><span className="score">{r.success}</span></td><td>{r.credits}</td><td><button className="icon-btn"><Icon name="more"/></button></td></tr>)}</tbody></table>
      <div className="pagination"><span>1–5 sur 24 services</span><div><button disabled>Précédent</button><button>Suivant</button></div></div>
    </section>
  </>
}

function Suppliers() {
  const [filter, setFilter] = useState('Tous')
  const rows = filter === 'Tous' ? suppliers : suppliers.filter(s => s.status === filter)
  return <>
    <PageHeader eyebrow="Commerce Management / Fournisseurs" title="Fournisseurs" description="Qualifiez, vérifiez et pilotez le réseau de partenaires commerciaux." action="Inviter un fournisseur"/>
    <div className="workflow-cards">
      {[['Dossiers à vérifier','14','4 urgents','shield'],['Documents incomplets','27','Relance requise','receipt'],['Fournisseurs vérifiés','1 842','+86 ce mois','check'],['Sous surveillance','18','3 à haut risque','alert']].map(([a,b,c,d],i)=><div key={a} className={i===0?'highlight-card':''}><span className="card-icon"><Icon name={d as IconName}/></span><div><small>{a}</small><strong>{b}</strong><p>{c}</p></div><Icon name="chevron"/></div>)}
    </div>
    <section className="panel table-panel">
      <div className="table-toolbar"><div className="tabs">{['Tous','Verified','Under Review','Documents Submitted'].map(x=><button key={x} className={filter===x?'active':''} onClick={()=>setFilter(x)}>{x}</button>)}</div><div className="toolbar-actions"><label className="searchbox"><Icon name="search"/><input placeholder="Nom, ID, secteur…"/></label><button className="secondary"><Icon name="filter"/>Filtres</button><button className="secondary"><Icon name="download"/>Exporter</button></div></div>
      <table className="data-table"><thead><tr><th>Fournisseur</th><th>Secteur</th><th>Marché</th><th>Vérification</th><th>Fiabilité</th><th>Volume 12 mois</th><th></th></tr></thead><tbody>{rows.map((r,i)=><tr key={r.id}><td><div className="person-cell"><span>{r.name.split(' ').map(x=>x[0]).slice(0,2).join('')}</span><div><strong>{r.name}</strong><small>{r.id}</small></div></div></td><td>{r.sector}</td><td>{r.country}</td><td><Status>{r.status}</Status></td><td><div className="reliability"><span><i style={{width:`${r.score}%`}}/></span><strong>{r.score}</strong></div></td><td><strong>{r.volume}</strong></td><td><button className="icon-btn"><Icon name="more"/></button></td></tr>)}</tbody></table>
    </section>
  </>
}

function Negotiations() {
  return <>
    <PageHeader eyebrow="Commerce Operations / Négociations" title="Negotiation Control Center" description="Supervisez les mandats actifs, les contre-offres et les décisions acheteurs."/>
    <div className="summary-strip negotiation-summary"><div><span>Actives maintenant</span><strong>286</strong><small>42 nécessitent une attention</small></div><div><span>Économies obtenues</span><strong>€412,8 k</strong><small className="positive">11,6 % en moyenne</small></div><div><span>Délai moyen</span><strong>18 h 24</strong><small className="positive">−2 h vs. mois dernier</small></div><div><span>Taux d’accord</span><strong>72,8 %</strong><small>objectif 75 %</small></div></div>
    <div className="neg-grid">
      <section className="panel neg-list"><div className="panel-head"><div><h2>Mandats actifs</h2><p>Triés par niveau d’attention</p></div><button className="secondary"><Icon name="filter"/>Filtrer</button></div>
        {[
          ['NEG-28412','Équipements chaîne du froid','Atlas Industrial Supply','€42 800','Intervention requise','12 min'],
          ['NEG-28408','Transport régional — contrat annuel','Nexa Logistics','€96 000','Contre-offre reçue','28 min'],
          ['NEG-28397','Mobilier de bureau · 240 unités','Kora Office Solutions','€31 200','En attente acheteur','1 h'],
          ['NEG-28384','Hébergement séminaire · 80 pers.','Meridian Hospitality','€18 650','Négociation IA','2 h'],
        ].map((r,i)=><button className={`neg-row ${i===0?'selected':''}`} key={r[0]}><div className="neg-top"><small>{r[0]}</small><span>{r[5]}</span></div><strong>{r[1]}</strong><p>{r[2]}</p><div><b>{r[3]}</b><Status tone={i===0?'bad':i===1?'warn':'info'}>{r[4]}</Status></div></button>)}
      </section>
      <section className="panel negotiation-detail">
        <div className="detail-head"><div><small>NEG-28412 · Mandat actif</small><h2>Équipements chaîne du froid</h2><p>Soro Industries ↔ Atlas Industrial Supply</p></div><button className="secondary">Intervenir</button></div>
        <div className="mandate"><div><small>Offre initiale</small><strong>€48 500</strong></div><Icon name="arrow"/><div><small>Dernière offre</small><strong>€42 800</strong></div><div className="saving"><small>Économie</small><strong>€5 700 · 11,8 %</strong></div></div>
        <div className="detail-tabs"><button className="active">Conversation</button><button>Offres</button><button>Mandat</button><button>Journal</button></div>
        <div className="timeline">
          <div><span className="timeline-icon system"><Icon name="bot"/></span><article><header><strong>Agent Négociation T-04</strong><small>09:42</small></header><p>Contre-proposition envoyée : remise de 12 % avec engagement sur un délai de livraison de 18 jours.</p><div className="offer-chip"><span>Notre proposition</span><strong>€41 950</strong><small>Paiement 40/60 · Livraison ≤ 18 j</small></div></article></div>
          <div><span className="timeline-icon supplier">AI</span><article><header><strong>Atlas Industrial Supply</strong><small>09:51 · Email</small></header><p>Nous pouvons accepter €42 800 avec livraison sous 21 jours. Le délai de 18 jours nécessiterait un supplément express.</p><div className="offer-chip received"><span>Contre-offre fournisseur</span><strong>€42 800</strong><small>Paiement 40/60 · Livraison 21 j</small></div></article></div>
          <div className="system-event"><span><Icon name="alert"/></span><p><strong>Limite de mandat atteinte</strong>L’écart de délai dépasse l’autorisation acheteur. Validation humaine nécessaire.</p><small>09:52</small></div>
        </div>
        <div className="decision-bar"><div><Icon name="lock"/><span><strong>Décision administrateur requise</strong>Autoriser 21 jours ou demander une nouvelle offre.</span></div><button className="secondary">Demander une offre</button><button className="primary">Autoriser 21 jours</button></div>
      </section>
    </div>
  </>
}

function AIControl() {
  return <>
    <PageHeader eyebrow="AI & Intelligence" title="AI Control Center" description="Orchestration, qualité, coûts et observabilité de l’intelligence Trezutil." action="Configurer un modèle"/>
    <div className="ai-hero">
      <div><span className="live-dot"/>Orchestration en direct</div><strong>1 284</strong><p>exécutions sur les 60 dernières minutes</p>
      <div className="ai-rates"><span><small>Réussite</small><b>98,7 %</b></span><span><small>Latence P95</small><b>2,8 s</b></span><span><small>Coût / exécution</small><b>€0,047</b></span><span><small>Fallback</small><b>2,1 %</b></span></div>
    </div>
    <div className="dashboard-grid ai-grid">
      <section className="panel wide"><div className="panel-head"><div><h2>Routage par capacité</h2><p>Modèles actifs et stratégies de repli</p></div><button className="text-btn">Configurer le routage</button></div>
        <table><thead><tr><th>Capacité</th><th>Modèle principal</th><th>Fallback</th><th>Limite</th><th>Santé</th></tr></thead><tbody>{[
          ['Analyse d’intention','Trezutil Reasoning 2','General Pro','8k tokens','Operational'],
          ['Recherche fournisseur','Search Grounded','General Flash','12k tokens','Operational'],
          ['Négociation','Trezutil Negotiator','Reasoning 2','24k tokens','Surveillance'],
          ['Classification documents','Document Vision','General Flash','16 pages','Operational'],
        ].map((r,i)=><tr key={r[0]}><td><strong>{r[0]}</strong></td><td><span className="model"><Icon name="spark"/>{r[1]}</span></td><td>{r[2]}</td><td>{r[3]}</td><td><Status tone={i===2?'warn':'good'}>{r[4]}</Status></td></tr>)}</tbody></table>
      </section>
      <section className="panel"><div className="panel-head"><div><h2>Budget IA</h2><p>Avril 2025</p></div><b>€21 840 / €30 000</b></div><div className="budget-ring"><div><strong>72,8%</strong><small>consommé</small></div></div><div className="budget-legend"><span><i/>Reasoning <b>€10,4 k</b></span><span><i/>Search <b>€6,2 k</b></span><span><i/>Vision & autres <b>€5,2 k</b></span></div></section>
      <section className="panel wide"><div className="panel-head"><div><h2>Exécutions récentes</h2><p>Traces unifiées des agents et modèles</p></div><button className="secondary"><Icon name="filter"/>Filtres</button></div>
        <div className="trace-list">{[
          ['run_9f82a1','Intent Analyzer','Intent → Procurement','1,82 s','€0,032','Succès'],
          ['run_9f829e','Negotiation Agent','Counter-offer evaluation','4,21 s','€0,114','Fallback'],
          ['run_9f8278','Supplier Discovery','Grounded search · Sénégal','6,88 s','€0,086','Succès'],
          ['run_9f8241','Document Verifier','KYB document extraction','2,47 s','€0,041','Succès'],
        ].map((r,i)=><div key={r[0]}><span className={`trace-status ${i===1?'fallback':''}`}/><code>{r[0]}</code><div><strong>{r[1]}</strong><small>{r[2]}</small></div><span>{r[3]}</span><span>{r[4]}</span><Status tone={i===1?'warn':'good'}>{r[5]}</Status><Icon name="chevron"/></div>)}</div>
      </section>
      <section className="panel"><div className="panel-head"><div><h2>Incidents modèles</h2><p>Dernières 24 heures</p></div><span className="count">3</span></div><div className="incident-list"><div><Status tone="bad">Élevé</Status><p><strong>Hausse des timeouts — Negotiator</strong><small>17 erreurs · depuis 14:08</small></p></div><div><Status tone="warn">Moyen</Status><p><strong>Dérive de coût — Reasoning 2</strong><small>+18 % vs. baseline</small></p></div><div><Status tone="info">Faible</Status><p><strong>Fallback Search Grounded</strong><small>Région Afrique de l’Ouest</small></p></div></div></section>
    </div>
  </>
}

function Billing() {
  return <>
    <PageHeader eyebrow="Credits & Revenue" title="Crédits & facturation" description="Pilotez l’économie des actions commerciales — la conversation reste toujours gratuite." action="Nouvelle règle tarifaire"/>
    <div className="principle"><Icon name="coins"/><div><strong>Credits power action, not conversation.</strong><p>Les crédits sont consommés uniquement lorsqu’une opération commerciale mesurable est exécutée.</p></div><button>Voir la politique</button></div>
    <div className="summary-strip"><div><span>Crédits en circulation</span><strong>8,42 M</strong><small>Particuliers + organisations</small></div><div><span>Consommés ce mois</span><strong>1,28 M</strong><small className="positive">+6,2 % vs. mars</small></div><div><span>Revenus crédits</span><strong>€148,6 k</strong><small className="positive">+14,1 %</small></div><div><span>Solde du ledger</span><strong>Équilibré</strong><small className="positive">0 anomalie</small></div></div>
    <div className="dashboard-grid">
      <section className="panel wide"><div className="panel-head"><div><h2>Tarification des actions</h2><p>Règles actives, sans déploiement de code</p></div><button className="text-btn">Toutes les règles</button></div>
        <table><thead><tr><th>Action commerciale</th><th>Déclencheur facturable</th><th>Crédits</th><th>Portée</th><th>Statut</th></tr></thead><tbody>{[
          ['Recherche qualifiée','Résultats validés et présentés','8','Global','Active'],
          ['Demande de devis','Fournisseur contacté','12 / fournisseur','Global','Active'],
          ['Négociation commerciale','Mandat accepté','18 + variable','Organisations','Active'],
          ['Commande orchestrée','Commande confirmée','1,2 % valeur','B2B','Active'],
          ['Conversation ordinaire','Jamais facturée','0','Global','Protected'],
        ].map((r,i)=><tr key={r[0]}><td><strong>{r[0]}</strong></td><td>{r[1]}</td><td><b>{r[2]}</b></td><td>{r[3]}</td><td><Status tone={i===4?'info':'good'}>{r[4]}</Status></td></tr>)}</tbody></table>
      </section>
      <section className="panel"><div className="panel-head"><div><h2>Répartition des soldes</h2><p>8,42 M crédits</p></div><button className="icon-btn"><Icon name="more"/></button></div><div className="balance-bars"><div><span>Organisations</span><strong>5,18 M · 61,5%</strong><i><b style={{width:'61.5%'}}/></i></div><div><span>Particuliers</span><strong>2,42 M · 28,7%</strong><i><b style={{width:'28.7%'}}/></i></div><div><span>Crédits promotionnels</span><strong>0,82 M · 9,8%</strong><i><b style={{width:'9.8%'}}/></i></div></div><button className="full-secondary">Ouvrir le grand livre <Icon name="arrow"/></button></section>
    </div>
  </>
}

function Integrations() {
  const integrations = [
    ['WhatsApp Business','Messagerie commerciale','Connecté','Operational','il y a 2 min','send'],
    ['Stripe','Paiements internationaux','Connecté','Operational','il y a 4 min','card'],
    ['Orange Money','Mobile Money','Incident','Dégradé','il y a 18 min','coins'],
    ['Google OAuth','Authentification','Connecté','Operational','il y a 6 min','lock'],
    ['SendGrid','Email transactionnel','Connecté','Operational','il y a 1 min','send'],
    ['DHL Logistics API','Logistique','Inactive','Non configuré','—','box'],
  ]
  return <>
    <PageHeader eyebrow="Integrations" title="Integrations Center" description="Connectivité, santé et événements des services externes de Trezutil." action="Ajouter une intégration"/>
    <div className="integration-health"><div><span className="big-health"><Icon name="check"/></span><div><strong>5 sur 6 intégrations actives sont opérationnelles</strong><p>Orange Money rencontre un taux d’échec supérieur au seuil configuré.</p></div></div><button>Voir l’incident</button></div>
    <div className="integration-grid">{integrations.map((r,i)=><div className="integration-card" key={r[0]}><div className="integration-top"><span className={`integration-logo i${i}`}><Icon name={r[5] as IconName}/></span><button className="icon-btn"><Icon name="more"/></button></div><h3>{r[0]}</h3><p>{r[1]}</p><div className="integration-meta"><span><small>Connexion</small><Status tone={r[2]==='Incident'?'bad':r[2]==='Inactive'?'neutral':'good'}>{r[2]}</Status></span><span><small>Santé</small><b className={r[3]==='Dégradé'?'bad-text':''}>{r[3]}</b></span></div><footer><span>Dernière synchro</span><strong>{r[4]}</strong><Icon name="chevron"/></footer></div>)}</div>
  </>
}

function Analytics() {
  return <>
    <PageHeader eyebrow="Analytics" title="Performance commerciale" description="Analyse multi-marchés de la conversion, des revenus et de l’efficacité opérationnelle." action="Créer un rapport"/>
    <div className="filter-bar"><button><Icon name="calendar"/>01 avr. — 30 avr. 2025</button><button><Icon name="globe"/>Tous les pays</button><button><Icon name="box"/>Tous les services</button><button><Icon name="users"/>Tous les utilisateurs</button><button className="clear">Réinitialiser</button></div>
    <div className="summary-strip"><div><span>GMV</span><strong>€2,48 M</strong><small className="positive">+12,4 %</small></div><div><span>Revenus nets</span><strong>€184,2 k</strong><small className="positive">+16,8 %</small></div><div><span>Conversion globale</span><strong>15,3 %</strong><small className="positive">+1,2 pt</small></div><div><span>Marge opérationnelle</span><strong>32,8 %</strong><small className="positive">+2,4 pt</small></div></div>
    <div className="analytics-grid"><section className="panel chart-panel"><div className="panel-head"><div><h2>Volume commercial & revenus</h2><p>Évolution quotidienne</p></div><div className="legend"><span><i/>GMV</span><span><i/>Revenus</span></div></div><div className="line-chart"><div className="y-labels"><span>120k</span><span>90k</span><span>60k</span><span>30k</span><span>0</span></div><svg viewBox="0 0 700 240" preserveAspectRatio="none"><g className="grid-lines"><path d="M0 10h700M0 65h700M0 120h700M0 175h700M0 230h700"/></g><path className="area" d="M0 190 C60 180 65 140 120 155 S190 110 240 125 S310 80 360 100 S430 60 480 75 S560 38 610 55 S665 28 700 35 L700 230 L0 230Z"/><path className="line" d="M0 190 C60 180 65 140 120 155 S190 110 240 125 S310 80 360 100 S430 60 480 75 S560 38 610 55 S665 28 700 35"/><path className="line secondary-line" d="M0 210 C70 205 80 190 140 195 S220 170 280 178 S370 145 430 158 S520 122 580 135 S650 105 700 112"/></svg><div className="x-labels"><span>1 avr.</span><span>6 avr.</span><span>12 avr.</span><span>18 avr.</span><span>24 avr.</span><span>30 avr.</span></div></div></section>
      <section className="panel"><div className="panel-head"><div><h2>Performance par marché</h2><p>Classée par GMV</p></div><button className="text-btn">Détails</button></div><div className="market-list">{[['Côte d’Ivoire','CI','€684 k','18,2%'],['Maroc','MA','€542 k','16,8%'],['Sénégal','SN','€418 k','14,6%'],['France','FR','€392 k','13,9%'],['Ghana','GH','€241 k','11,4%']].map((r,i)=><div key={r[0]}><span className="rank">{i+1}</span><span className="flag">{r[1]}</span><p><strong>{r[0]}</strong><small>{r[3]} conversion</small></p><b>{r[2]}</b></div>)}</div></section></div>
  </>
}

function Workflow() {
  return <>
    <PageHeader eyebrow="Services / Négociation commerciale / Workflow" title="Workflow opérationnel" description="Version 12 · Publiée le 18 avril 2025 par Amine B." action="Publier les changements"/>
    <div className="workflow-shell">
      <aside className="node-panel"><div className="node-search"><Icon name="search"/><input placeholder="Rechercher un node"/></div><h4>DÉCLENCHEURS</h4><button><span className="node-icon trigger"><Icon name="target"/></span>Intention qualifiée</button><button><span className="node-icon"><Icon name="send"/></span>Événement externe</button><h4>ACTIONS COMMERCE</h4><button><span className="node-icon action"><Icon name="search"/></span>Rechercher fournisseurs</button><button><span className="node-icon action"><Icon name="quote"/></span>Solliciter une offre</button><button><span className="node-icon action"><Icon name="message"/></span>Négocier</button><h4>LOGIQUE</h4><button><span className="node-icon logic"><Icon name="route"/></span>Condition</button><button><span className="node-icon logic"><Icon name="users"/></span>Validation humaine</button></aside>
      <div className="canvas">
        <div className="canvas-toolbar"><button><Icon name="plus"/></button><button>−</button><span>86%</span><i/><button><Icon name="more"/></button></div>
        <svg className="connections" viewBox="0 0 1000 600" preserveAspectRatio="none"><path d="M160 130 C240 130 210 230 300 230"/><path d="M480 230 C550 230 530 125 610 125"/><path d="M480 230 C550 230 530 345 610 345"/><path d="M790 125 C850 125 840 230 900 230"/><path d="M790 345 C850 345 840 230 900 230"/></svg>
        <div className="flow-node start" style={{left:'3%',top:'14%'}}><header><span><Icon name="target"/>DÉCLENCHEUR</span><Icon name="more"/></header><strong>Intention qualifiée</strong><p>Confiance ≥ 0,82</p><i className="port right"/></div>
        <div className="flow-node" style={{left:'28%',top:'31%'}}><i className="port left"/><header><span><Icon name="search"/>ACTION</span><Icon name="more"/></header><strong>Rechercher fournisseurs</strong><p>Top 12 · fournisseurs vérifiés</p><i className="port right"/></div>
        <div className="flow-node condition" style={{left:'59%',top:'13%'}}><i className="port left"/><header><span><Icon name="route"/>CONDITION</span><Icon name="more"/></header><strong>≥ 3 fournisseurs trouvés ?</strong><p>Branche Oui / Non</p><i className="port right"/></div>
        <div className="flow-node human" style={{left:'59%',top:'50%'}}><i className="port left"/><header><span><Icon name="users"/>VALIDATION</span><Icon name="more"/></header><strong>Revue opérateur sourcing</strong><p>SLA 4 h · Escalade automatique</p><i className="port right"/></div>
        <div className="flow-node" style={{left:'82%',top:'31%'}}><i className="port left"/><header><span><Icon name="quote"/>ACTION</span><Icon name="more"/></header><strong>Solliciter les offres</strong><p>Email + WhatsApp · délai 48 h</p><i className="port right"/></div>
        <div className="minimap"><span/><span/><span/><span/></div>
      </div>
      <aside className="properties"><div className="prop-head"><div><small>ACTION</small><strong>Rechercher fournisseurs</strong></div><button><Icon name="close"/></button></div><label>Nom du node<input value="Rechercher fournisseurs" readOnly/></label><label>Nombre maximal<input value="12" readOnly/></label><label>Statut fournisseur<select><option>Vérifié uniquement</option></select></label><label>Score minimum<div className="range-row"><input type="range" defaultValue="75"/><b>75</b></div></label><label className="toggle-row"><div><strong>Élargissement géographique</strong><small>Si moins de 3 résultats</small></div><input type="checkbox" defaultChecked/></label><div className="prop-footer"><button className="danger-text">Supprimer le node</button></div></aside>
    </div>
  </>
}

function GenericPage({ title }: { title: string }) {
  return <><PageHeader eyebrow="Trezutil Control Center" title={title} description="Supervision et configuration centralisées de ce domaine opérationnel." action="Nouvelle action"/><div className="generic-layout"><section className="panel"><div className="empty-state"><span><Icon name="settings" size={28}/></span><h2>Espace de gestion {title}</h2><p>Les données et contrôles de ce module sont disponibles depuis cet espace sécurisé.</p><button className="primary">Configurer le module</button></div></section><section className="panel"><div className="panel-head"><div><h2>Activité récente</h2><p>Journal des dernières modifications</p></div></div><div className="audit-mini">{['Configuration mise à jour','Accès administrateur vérifié','Rapport mensuel généré','Politique appliquée'].map((x,i)=><div key={x}><span>{i+1}</span><p><strong>{x}</strong><small>Par Control Center · il y a {i+1} h</small></p></div>)}</div></section></div></>
}

function Wizard({ close }: { close: () => void }) {
  const [step, setStep] = useState(1)
  return <div className="modal-backdrop" onMouseDown={e=>e.target===e.currentTarget&&close()}><div className="wizard">
    <div className="wizard-head"><div><small>NOUVEAU SERVICE</small><h2>Configurer une capacité commerciale</h2></div><button className="icon-btn" onClick={close}><Icon name="close"/></button></div>
    <div className="stepper">{['Informations','Règles métier','Workflow','IA & tarification'].map((x,i)=><div className={step===i+1?'active':step>i+1?'done':''} key={x}><span>{step>i+1?<Icon name="check" size={14}/>:i+1}</span><p>{x}</p></div>)}</div>
    <div className="wizard-body">{step===1?<><div className="form-title"><h3>Informations générales</h3><p>Définissez l’identité et le périmètre initial du service.</p></div><div className="form-grid"><label className="full">Nom du service<input placeholder="Ex. Approvisionnement en équipements"/></label><label className="full">Description<textarea placeholder="Décrivez ce que Trezutil peut exécuter pour l’utilisateur…"/></label><label>Catégorie<select><option>Sélectionner une catégorie</option><option>Sourcing</option><option>Commerce assisté</option></select></label><label>Code interne<input placeholder="service_code"/></label><label className="full">Secteurs concernés<div className="tag-input"><span>Industrie <button>×</button></span><span>Commerce B2B <button>×</button></span><input placeholder="Ajouter un secteur"/></div></label></div></>:<div className="step-placeholder"><span><Icon name={step===2?'briefcase':step===3?'route':'spark'} size={30}/></span><h3>{step===2?'Règles métier et éligibilité':step===3?'Workflow opérationnel':'Configuration IA et crédits'}</h3><p>Configurez les paramètres détaillés de cette étape. Vous pourrez les modifier après la création.</p><div className="placeholder-lines"><i/><i/><i/></div></div>}</div>
    <div className="wizard-footer"><button className="secondary" onClick={step===1?close:()=>setStep(step-1)}>{step===1?'Annuler':'Précédent'}</button><span>Étape {step} sur 4</span><button className="primary" onClick={step===4?close:()=>setStep(step+1)}>{step===4?'Créer le service':'Continuer'}<Icon name="arrow"/></button></div>
  </div></div>
}

export default function App() {
  const [active, setActive] = useState('Command Center')
  const [collapsed, setCollapsed] = useState<string[]>(['System'])
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [wizard, setWizard] = useState(false)
  const currentIcon = useMemo(() => navigation.flatMap(g=>g.items).find(i=>i.label===active)?.icon || 'grid', [active])
  const content = active === 'Command Center' ? <Dashboard/> : active === 'Services' ? <Services openWizard={()=>setWizard(true)}/> : active === 'Fournisseurs' || active === 'Vérification fournisseurs' ? <Suppliers/> : active === 'Négociations' ? <Negotiations/> : active === 'AI Control Center' ? <AIControl/> : active === 'Crédits & facturation' ? <Billing/> : active === 'Integrations Center' ? <Integrations/> : active === 'Analytics & rapports' ? <Analytics/> : active === 'Fonctionnalités & modules' ? <Workflow/> : <GenericPage title={active}/>
  return <div className="app-shell">
    <aside className={`sidebar ${sidebarOpen?'open':''}`}>
      <div className="brand"><div className="brand-mark"><span/><span/><span/></div><div><strong>TREZUTIL</strong><small>CONTROL CENTER</small></div><button className="mobile-close" onClick={()=>setSidebarOpen(false)}><Icon name="close"/></button></div>
      <nav>{navigation.map(group=><div className="nav-group" key={group.group}><button className="group-title" onClick={()=>setCollapsed(c=>c.includes(group.group)?c.filter(x=>x!==group.group):[...c,group.group])}><span>{group.group}</span><Icon name="chevron" size={13}/></button>{!collapsed.includes(group.group)&&<div className="nav-items">{group.items.map(item=><button key={item.label} className={active===item.label?'active':''} onClick={()=>{setActive(item.label);setSidebarOpen(false)}}><Icon name={item.icon}/><span>{item.label}</span>{item.label==='Alertes et incidents'&&<b>3</b>}{item.label==='Vérification fournisseurs'&&<b className="neutral">14</b>}</button>)}</div>}</div>)}</nav>
      <div className="sidebar-foot"><div className="environment"><span/><div><small>ENVIRONNEMENT</small><strong>Production</strong></div><Icon name="chevron" size={14}/></div><div className="profile"><span>AB</span><div><strong>Amine B.</strong><small>Super Administrator</small></div><button><Icon name="more"/></button></div></div>
    </aside>
    <div className="main-shell">
      <header className="topbar"><button className="mobile-menu" onClick={()=>setSidebarOpen(true)}><Icon name="menu"/></button><div className="breadcrumb"><span className="crumb-icon"><Icon name={currentIcon}/></span><strong>{active}</strong></div><label className="global-search"><Icon name="search"/><input placeholder="Rechercher partout dans Trezutil…"/><kbd>⌘ K</kbd></label><div className="top-actions"><button><Icon name="bell"/><i/></button><button><Icon name="command"/></button><span className="top-avatar">AB</span></div></header>
      <main>{content}</main>
    </div>
    {wizard&&<Wizard close={()=>setWizard(false)}/>}
  </div>
}
